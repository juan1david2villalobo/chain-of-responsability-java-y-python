/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liquidacion;

/**
 *
 * @author Estudiantes
 */
public class Nomina extends profesor{

    // inicializa la parte de unidad e inicializa el estado propio del Coronel (_orden)

    public Nomina (String cargo, String salario) {
      super(cargo);
      _salario = salario;
    }

    /* refinamiento del servicio que utiliza la cadena de responsabilidad, resolviendo
       localmente si tiene órdenes específicas o comportándose convencionalmente en
       caso contrario */

    public String salario()    { return (_salario != null ? _salario : super.salario()); }

    public String toString() { return ("Nomina " + super.toString()); }

    private String _salario;
}
