/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liquidacion;

/**
 *
 * @author Estudiantes
 */
public class honorarios extends profesor {

    // el constructor sólo tiene que inicializar la parte correspondiente a la superclase

    public honorarios(String cargo) {
        super(cargo);
    }
    
    public String toString() { return ("honorarios " + super.toString()); }
}
