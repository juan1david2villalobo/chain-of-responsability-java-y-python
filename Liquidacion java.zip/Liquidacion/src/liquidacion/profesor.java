/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liquidacion;

/**
 *
 * @author Estudiantes
 */
public abstract class profesor {

    /* en el constructor, además de un cargo para el profesor, se inicializa la referencia
       que implementa la cadena de responsabilidad (_pago) */

    public profesor(String cargo) { 
        _pago = null; 
        _cargo = cargo;
    }

    public String toString() { return _cargo; }

    

    public void establecerPago(profesor pago) { _pago = pago; }

   
    public String salario() {
        return (_pago != null ? _pago.salario() : "(pago de salario)"); 
    }

    private profesor _pago;
    private String _cargo;

}