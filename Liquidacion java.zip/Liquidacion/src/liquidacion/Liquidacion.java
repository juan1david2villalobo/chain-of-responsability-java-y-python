/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liquidacion;

/**
 *
 * @author Estudiantes
 */
public class Liquidacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
      profesor planta  = new Nomina("Planta", null);
      profesor catedratico = new Nomina("catedratico", "pagando liquidacion por tiempo trabajado");
      profesor administrativo  = new honorarios("administrativo");
      profesor prestacionServicios = new honorarios("prestacionServicios");

      System.out.println(prestacionServicios.salario());    // prestacion de servicios ->

      prestacionServicios.establecerPago(catedratico);
      System.out.println(prestacionServicios.salario());    // prestacion de servicios -> catedratico

      administrativo.establecerPago(prestacionServicios);
      System.out.println(administrativo.salario());  
    }
    
}
